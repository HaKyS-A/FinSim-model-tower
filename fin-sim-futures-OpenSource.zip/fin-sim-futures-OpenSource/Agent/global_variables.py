# This is all global variance file
import os

Usage = 0
Prompt_Usage=0
Completion_Usage=0